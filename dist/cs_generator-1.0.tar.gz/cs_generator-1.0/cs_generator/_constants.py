"""
Package metadata
"""

__author__ = "lihailin"
__license__ = "MIT"
__url__ = "https://github.com/fortfall/cs_generator"
__version__ = "1.0"
